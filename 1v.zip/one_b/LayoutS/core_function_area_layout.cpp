//核心功能区

//控件
//1.中止播放键
//2.上一个视频 按键
//3.播放/暂停键
//4.下一个视频 案件
//5.音量控制控件

//音量控制控件中使用一个自定义水平布局，布局内控件有：
//左侧：音量图标/静音键（点击图标实现静音/不静音）
//右侧：音量滑块

#include <LayoutH/core_function_area_layout.h>
#include <QWidget>
void CoreFunctionAreaLayout::setGeometry(const QRect &rect){

}

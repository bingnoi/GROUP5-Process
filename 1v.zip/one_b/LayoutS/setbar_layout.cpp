//底部区域布局，采用垂直布局，顶部为进度条控件，下方则是播放功能区

#include <LayoutH/set_bar_layout.h>
#include <QWidget>
#include <base_widget.h>
#include <iostream>
void SetBarLayout::setGeometry(const QRect &r){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName()== "ProgressBar"){
            w->setGeometry(r.left(),r.top(),r.width(),30);
        }else{
            w->setGeometry(r.left(),r.top()+32,r.width(),68);
        }
    }
}

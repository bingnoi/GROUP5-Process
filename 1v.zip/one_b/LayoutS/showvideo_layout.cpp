#include <LayoutH/show_video_layout.h>
#include <QWidget>
#include <QtWidgets>
#include <iostream>
#include <QLabel>
#include <base_widget.h>
using namespace std;
void ShowVideoLayout::setGeometry(const QRect &r){
    mSetGeometry(r);
}


void ShowVideoLayout::mSetGeometry(const QRect&r){
    if(showState == 0){
        if(state == 0){
            s0SetGeometry(r);
        }else if(state == 1){
            s3SetGeometry(r);
        }

    }
    else if(showState == 1){
        if(state == 0){
            s1SetGeometry(r);
        }else if(state == 1){
            s4SetGeometry(r);
        }
    }
    else if(showState == 2){
        if(state == 0){
            s2SetGeometry(r);
        }else if(state == 1){
            s5SetGeometry(r);
        }
    }
}
void ShowVideoLayout::s0SetGeometry(const QRect&r){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName()== "NavBar"){
            w->setGeometry(r.left(),r.top(),r.width(),50);
        }else if(w->getName()=="SideBar"){
            w->setGeometry(r.width()-20,r.height()/2,70,50);
        }else if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

void ShowVideoLayout::s3SetGeometry(const QRect&r){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName()== "NavBar"){
            w->setGeometry(r.left(),r.top(),r.width(),50);
        }else if(w->getName()=="ExtendSpace"){
            w->setGeometry(r.width()-200,0,200,r.height());
        }else if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

void ShowVideoLayout::s1SetGeometry(const QRect&r){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName() == "SetBar"){
            w->setGeometry(r.left(),r.height()-100,r.width(),100);
        }else if(w->getName()=="SideBar"){
            w->setGeometry(r.width()-20,r.height()/2,70,50);
        }else if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

void ShowVideoLayout::s4SetGeometry(const QRect&r){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName() == "SetBar"){
            w->setGeometry(r.left(),r.height()-100,r.width(),100);
        }else if(w->getName()=="ExtendSpace"){
            w->setGeometry(r.width()-200,0,200,r.height());
        }else if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

void ShowVideoLayout::s2SetGeometry(const QRect&r){

    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else if(w->getName()=="SideBar"){
            w->setGeometry(r.width()-20,r.height()/2,70,50);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

void ShowVideoLayout::s5SetGeometry(const QRect&r){

    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName() == "ShowVideoWidget"){
            w->setGeometry(0,100,r.width(),450);
        }else if(w->getName()=="ExtendSpace"){
            w->setGeometry(r.width()-200,0,200,r.height());
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}

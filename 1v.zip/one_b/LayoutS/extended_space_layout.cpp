//侧边扩展区域

//控件我太菜了，不清楚有哪些
#include <base_widget.h>
#include <LayoutH/extended_space_layout.h>
#include <QWidget>
#include <iostream>
using namespace std;
void ExtendedSpaceLayout::setGeometry(const QRect &r){
    for (int i=0;i<list.size();i++){
        QLayoutItem* o  = list.at(i);
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName()== "infoItem"){
            w->setGeometry(r.width()-200,90*i,200,80);
        }
        else if(w->getName()=="Close"){
            w->setGeometry(r.width()-200,r.height()/2,30,30);
        }
        else{
            w->setGeometry(-1,-1,0,0);
        }
 }
}

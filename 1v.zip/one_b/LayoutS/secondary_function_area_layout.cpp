//次要功能区

//用于实现像全屏播放切换按键等非核心的功能按键

//可能的控件
//1.全屏按键
//2.倍速？

#include <LayoutH/secondary_function_area_layout.h>
#include <QWidget>
void SecondaryFunctionAreaLayout::setGeometry(const QRect &rect){

}


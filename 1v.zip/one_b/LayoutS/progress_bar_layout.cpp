//进度条控件内部布局，水平布局，包含三个控件

//左侧：跳至视频开头按键？ 或者快退键
//中间：视频进度滑动条
//右侧：跳至视频结尾按键？ 或者快进键

#include <LayoutH/progress_bar_layout.h>
#include <QWidget>
#include <QPushButton>
#include <base_slider.h>
#include <iostream>
using namespace std;
void ProgressBarLayout::setGeometry(const QRect &r){
    for(int i=0;i<list.size();i++){
        QLayoutItem *o = list.at(i);
        QPushButton *label = static_cast<QPushButton *>(o->widget());
//        printf("%s\n",label->text().toStdString());
        if(label->text() == "<<"){
            label->setGeometry(20,2.5,40,25);
        }else if(label->text() == ">>"){
            label->setGeometry(r.width()-60,2.5,40,25);
        }else if(label->text() == "show"){
            label->setGeometry(70,2.5,300,25);
        }else{
            label->setGeometry(-1,-1,0,0);
        }
    }
}

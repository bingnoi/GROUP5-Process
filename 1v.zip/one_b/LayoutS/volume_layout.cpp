//音量控件内部布局，水平布局，包含两个控件

//左侧：音量图标/静音键（点击图标实现静音/不静音）
//右侧：音量滑块

#include <LayoutH/volume_layout.h>
#include <QWidget>
void VolumeLayout::setGeometry(const QRect &rect){

}

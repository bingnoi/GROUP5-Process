//播放功能区布局，位于进度条的下方，用于摆放除进度条以外的功能控件
//内部子控件采用水平布局

#include <LayoutH/set_bar_function_area_layout.h>
#include <QWidget>
#include <base_widget.h>
#include <iostream>
using namespace std;
void SetBarFunctionAreaLayout::setGeometry(const QRect &rect){
    QList<QLayoutItem*>::iterator it = list.begin();
    for(;it != list.end(); it++){
        QLayoutItem* o  = *it;
        BaseWidget* w = static_cast<BaseWidget*>(o->widget());
        if(w->getName()== "TimeProgress"){
            w->setGeometry(25,15,200,40);
        }else if(w->getName() == "CoreFunctionArea"){
            w->setGeometry(400,5,500,60);
        }else if(w->getName() == "SecondaryFunctionArea"){
            w->setGeometry(1100,10,100,50);
        }else{
            w->setGeometry(-1,-1,0,0);
        }
    }
}


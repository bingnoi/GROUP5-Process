#include "LayoutH/simple_V_layout.h"
#include <iostream>
#include <QLabel>
#include <iostream>
using namespace std;
void SimpleVLayout::setGeometry(const QRect &r){
    int height = m_height;
    int index = 0;
    QList<QLayoutItem*>::iterator it = list.begin();
    for(; it != list.end(); it++){

        QWidget* w =(*it)->widget();
        w->setGeometry(r.left(),index * 70, r.width(),height);
        cout << "Start at: " << index * 70 << endl;
        index++;
    }
}

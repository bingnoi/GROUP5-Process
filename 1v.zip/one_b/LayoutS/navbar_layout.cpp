#include <LayoutH/navbar_layout.h>
#include <QWidget>
void NavBarLayout::setGeometry(const QRect &rect){

}

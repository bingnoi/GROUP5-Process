#ifndef INFOITEM_H
#define INFOITEM_H
#include <QWidget>
#include <string>
#include <base_widget.h>
#include <QMouseEvent>
class infoItem : public BaseWidget
{
    Q_OBJECT
public:
    infoItem();
    infoItem(string name);
    infoItem(string name,string timelong,string author,string url);
    string getName() override{
        if(this->name.length())
            return this->name;
        return "infoItem";
    }
    void mousePressEvent(QMouseEvent *event);
private:
    string name;
    string sourceUrl;
signals:
    void mouseClick(string word);
};

#endif // INFOITEM_H

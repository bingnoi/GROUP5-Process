//#ifndef MYPLAYER_H
//#define MYPLAYER_H
//#include <QApplication>
//#include <QMediaPlayer>
//#include <vector>
//#include <QTimer>
//using namespace std;

//class MyPlayer : public QMediaPlayer{
//Q_OBJECT
//public:
//    MyPlayer();
//    ~MyPlayer();
//};

//#endif // MYPLAYER_H

#include "mainwindow.h"
#include <QApplication>
#include "WidgetH/show_video.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    show_video w;
    w.show();

    return a.exec();
}

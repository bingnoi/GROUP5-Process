#ifndef NAVBAR_LAYOUT_H
#define NAVBAR_LAYOUT_H
#include <basic_layout.h>
class NavBarLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};

#endif // NAVBAR_LAYOUT_H

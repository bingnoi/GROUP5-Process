#ifndef SHOWVIDEO_LAYOUT_H
#define SHOWVIDEO_LAYOUT_H
#include <basic_layout.h>
#include <iostream>
using namespace std;
class ShowVideoLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
    void changeState(int target_state){
        showState = target_state;
    }
    void setState(int s){
            state = s;
    }
    int getShowState(){
        return showState;
    }
private:
    int showState = 2;
    int state = 0;
    void mSetGeometry(const QRect&);
    void s0SetGeometry(const QRect&);
    void s1SetGeometry(const QRect&);
    void s2SetGeometry(const QRect&);
    void s3SetGeometry(const QRect&);
    void s4SetGeometry(const QRect&);
    void s5SetGeometry(const QRect&);
};

#endif // SHOWVIDEO_LAYOUT_H

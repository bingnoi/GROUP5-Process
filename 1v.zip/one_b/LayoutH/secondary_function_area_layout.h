#ifndef SECONDARY_FUNCTION_LAYOUT_H
#define SECONDARY_FUNCTION_LAYOUT_H
#include <basic_layout.h>
class SecondaryFunctionAreaLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // SECONDARY_FUNCTION_LAYOUT_H

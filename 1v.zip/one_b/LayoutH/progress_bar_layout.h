#ifndef PROGRESS_BAR_LAYOUT_H
#define PROGRESS_BAR_LAYOUT_H
#include <basic_layout.h>
class ProgressBarLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // PROGRESS_BAR_LAYOUT_H

#ifndef SET_BAR_FUNCTION_AREA_LAYOUT_H
#define SET_BAR_FUNCTION_AREA_LAYOUT_H
#include <basic_layout.h>
class SetBarFunctionAreaLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // SET_BAR_FUNCTION_AREA_LAYOUT_H

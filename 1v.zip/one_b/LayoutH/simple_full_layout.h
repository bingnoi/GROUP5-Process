#ifndef SIMPLE_FULL_LAYOUT_H
#define SIMPLE_FULL_LAYOUT_H
#include "basic_layout.h"
#include "iostream"
#include <QWidget>
#include <QScrollArea>
class SimpleFullLayout: public BasicLayout
{
    void setGeometry(const QRect &r) override{
        if(list.size()< 1){
            std::cout<<"not enough widget"
                    <<__FILE__<<" "<<__LINE__<<std::endl;

        }

        QWidget*w = list.at(0)->widget();
        w->setGeometry(r.width()-200,0,200,r.height());
        QWidget*side = list.at(1)->widget();
        side->setGeometry(r.width()-200,r.height()/2,50,50);
    };
};

#endif // SIMPLE_FULL_LAYOUT_H

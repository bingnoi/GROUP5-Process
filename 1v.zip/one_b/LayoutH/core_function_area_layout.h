#ifndef CORE_FUNCTION_AREA_LAYOUT_H
#define CORE_FUNCTION_AREA_LAYOUT_H
#include <basic_layout.h>
class CoreFunctionAreaLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // CORE_FUNCTION_AREA_LAYOUT_H

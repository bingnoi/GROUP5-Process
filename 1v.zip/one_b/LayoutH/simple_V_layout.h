#ifndef SIMPLE_V_LAYOUT_H
#define SIMPLE_V_LAYOUT_H

#include "basic_layout.h"
class SimpleVLayout : public BasicLayout
{
    void setGeometry(const QRect &rect) override;
public:
    SimpleVLayout(int height = 60){
        m_height = height;
    }

    int getHeightHint(){
        return m_height;
    }
private:
    int m_height;
};

#endif // SIMPLE_V_LAYOUT_H

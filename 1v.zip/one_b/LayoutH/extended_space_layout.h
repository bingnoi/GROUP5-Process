#ifndef EXTENDED_SPACE_LAYOUT_H
#define EXTENDED_SPACE_LAYOUT_H
#include <basic_layout.h>
class ExtendedSpaceLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // EXTENDED_SPACE_LAYOUT_H

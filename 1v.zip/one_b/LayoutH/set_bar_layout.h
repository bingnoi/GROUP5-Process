#ifndef SETBAR_LAYOUT_H
#define SETBAR_LAYOUT_H
#include <basic_layout.h>
class SetBarLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // SETBAR_LAYOUT_H

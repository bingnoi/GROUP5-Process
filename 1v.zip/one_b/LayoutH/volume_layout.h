#ifndef VOLUME_LAYOUT_H
#define VOLUME_LAYOUT_H
#include <basic_layout.h>
class VolumeLayout : public BasicLayout{
public:
    virtual void setGeometry(const QRect &rect);
};
#endif // VOLUME_LAYOUT_H

#ifndef INNER_LAYOUT_H
#define INNER_LAYOUT_H
#include <basic_layout.h>
#include <QScrollArea>
class inner_layout : public BasicLayout
{
public:
    virtual void setGeometry(const QRect &rect) override;
    QScrollArea *scrollarea;
    void setscroll(QScrollArea* scroll);
};

#endif // INNER_LAYOUT_H

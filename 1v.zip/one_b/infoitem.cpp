#include "infoitem.h"
#include <QWidget>
#include <QPalette>
#include <QLabel>
#include <QLayout>
#include <QPushButton>
#include <QMouseEvent>
#include <iostream>
infoItem::infoItem()
{
    QPalette p;
    p.setColor(QPalette::Window,QColor(00,250,53));
    setAutoFillBackground(true);
    setPalette(p);

    QGridLayout* mlayout = new QGridLayout(this);
    QLabel* name= new QLabel("PYYYDS");
    QLabel* timeLong=new QLabel("12:30");
    QLabel* author=new QLabel("PY");
    mlayout->addWidget(name,0,0,1,2);
    mlayout->addWidget(timeLong,0,1,1,2);
    mlayout->addWidget(author,1,0,1,2);
    setLayout(mlayout);
}

infoItem::infoItem(string info){
    QPalette p;
    p.setColor(QPalette::Window,QColor(00,250,53));
    setAutoFillBackground(true);
    setPalette(p);
    this->name=info;
    QGridLayout* mlayout = new QGridLayout(this);
    QLabel* name= new QLabel(">>");
    mlayout->addWidget(name,0,0,1,2);
    setLayout(mlayout);
}

infoItem::infoItem(string name,string timelong,string author,string url){
    QPalette p;
    p.setColor(QPalette::Window,QColor(00,00,255));
    setAutoFillBackground(true);
    setPalette(p);
    this->name="infoItem";
    this->sourceUrl=url;
    QGridLayout* mlayout = new QGridLayout(this);
    QLabel* fname= new QLabel(QString::fromStdString(name));
    QLabel* ftimeLong=new QLabel(QString::fromStdString(timelong));
    QLabel* fauthor=new QLabel(QString::fromStdString(author));
    mlayout->addWidget(fname,0,0,1,2);
    mlayout->addWidget(ftimeLong,0,1,1,2);
    mlayout->addWidget(fauthor,1,0,1,2);
    setLayout(mlayout);
}

void infoItem::mousePressEvent(QMouseEvent *event){
    emit(this->mouseClick(this->sourceUrl));
}


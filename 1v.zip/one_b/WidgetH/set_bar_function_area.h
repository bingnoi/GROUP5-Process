#ifndef SET_BAR_FUNCTION_AREA_H
#define SET_BAR_FUNCTION_AREA_H
#include <QWidget>
#include <string>
#include <base_widget.h>
using namespace std;
class SetBarFunctionArea : public BaseWidget{
    Q_OBJECT
public:
    SetBarFunctionArea();
    string getName() override{
        return "SetBarFunctionArea";
    }
    void pause();
    void play();
    void control();
private slots:
    void getAlltime(qint64);
    void getCurtime(qint64);
    void volume(int);
signals:
    void pausevideo();
    void playvideo();
    void controlvideo();
    void durationchange(qint64);
    void positionchange(qint64);
    void changevolume(int);
};
#endif // SET_BAR_FUNCTION_AREA_H


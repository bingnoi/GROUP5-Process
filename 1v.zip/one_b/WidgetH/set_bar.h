#ifndef SET_BAR_H
#define SET_BAR_H
#include <QWidget>
#include <string>
#include <base_widget.h>
#include <WidgetH/set_bar_function_area.h>
#include <iostream>
using namespace std;
class SetBar : public BaseWidget{
    Q_OBJECT
public:
    SetBar();
    string getName() override{
        return "SetBar";
    }
    void pause();
    void play();
    void control();
private slots:
    void getAlltime(qint64);
    void getCurtime(qint64);
    void onTimeOut(qint64);
    void SliderClicked(int);
    void SliderMove(int);
    void SliderRealse();
    void volume(int);
    void next();
    void pre();
signals:
    void playvideo();
    void pausevideo();
    void controlvideo();
    void durationchange(qint64);
    void positionchange(qint64);
    void costomSliderClicked(int);
    void movevideo(int);
    void realsevideo();
    void Sliderchange(qint64);
    void changevolume(int);
    void fastnext();
    void fastpre();
};

#endif // SET_BAR_H


#ifndef PROGRESS_BAR_H
#define PROGRESS_BAR_H
#include "base_widget.h"
#include <string>
#include <myslider.h>
using namespace std;
class ProgressBar : public BaseWidget{
    Q_OBJECT
public:
    ProgressBar();
    string getName() override{
        return "ProgressBar";
    }
private:
    MySlider* show;
private slots:
    void getCurtime(qint64);
    void getAlltime(qint64);
    void SliderClicked();
    void SliderMove();
    void SliderRealse();
    void next();
    void pre();
signals:
    void costomSliderClicked(int);
    void movevideo(int);
    void relasevideo();
    void fastnext();
    void fastpre();
private:
    qint64 duration;
};
#endif // PROGRESS_BAR_H



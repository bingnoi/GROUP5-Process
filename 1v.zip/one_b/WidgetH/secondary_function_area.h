#ifndef SECONDARY_FUNCTION_AREA_H
#define SECONDARY_FUNCTION_AREA_H
#include <base_widget.h>
#include <string>
using namespace std;
class SecondaryFunctionArea : public BaseWidget{
public:
    SecondaryFunctionArea();
    string getName() override{
        return "SecondaryFunctionArea";
    }
};

#endif // SECONDARY_FUNCTION_AREA_H


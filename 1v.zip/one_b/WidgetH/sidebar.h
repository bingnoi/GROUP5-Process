#ifndef SIDEBAR_H
#define SIDEBAR_H
#include <QWidget>
#include <string>
#include <base_widget.h>
#include<QMouseEvent>
using namespace std;
class SideBar : public BaseWidget
{
    Q_OBJECT
public:
    SideBar();
    string getName() override{
        return "SideBar";
    }
protected:
    void mousePressEvent(QMouseEvent *event);

signals:
    void mouseClick(QString);
public slots:
};


#endif // SIDEBAR_H


#ifndef EXTEND_SPACE_H
#define EXTEND_SPACE_H
#include <QWidget>
#include <string>
#include <base_widget.h>
using namespace std;
class ExtendSpace : public BaseWidget{\
    Q_OBJECT
public:
    ExtendSpace();
        string getName() override{
            return "ExtendSpace";
        }
    void sayClick();
    void say(string);
private slots:
    void info(string,string,string,string);
signals:
        void mouseClick(QString);
        void videoinfo(string,string,string,string);
};

#endif // EXTEND_SPACE_H


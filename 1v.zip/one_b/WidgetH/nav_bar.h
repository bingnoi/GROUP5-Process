#ifndef NAV_BAR_H
#define NAV_BAR_H
#include "base_widget.h"
#include <string>
using namespace std;
class NavBar : public BaseWidget{
public:
    NavBar();
    string getName() override{
        return "NavBar";
    }
};

#endif // NAV_BAR_H

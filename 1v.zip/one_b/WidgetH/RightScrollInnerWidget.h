#ifndef RIGHTSCROLLINNERWIDGET_H
#define RIGHTSCROLLINNERWIDGET_H
#include"base_widget.h"
#include "LayoutH/simple_V_layout.h"
#include <QFile>
#include <QFileInfo>
#include <iostream>
#include <QTextStream>
#include <QDebug>
#include "infoitem.h"
#include "extended_space.h"
#include <QDir>
class RightScrollInnerWidget : public BaseWidget
{
    Q_OBJECT
public:
    SimpleVLayout* layout;
    RightScrollInnerWidget(){
        layout= new SimpleVLayout();

        void (infoItem:: *infoItemSignal)(string )=&infoItem::mouseClick;
        void (RightScrollInnerWidget:: *sayf)(string )=&RightScrollInnerWidget::sayf;

        QFile file("set.txt");
        if(!file.exists())
            cout << "false" << endl;
        if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
            cout << "false" << endl;
        while(!file.atEnd()){
            cout << 1 << endl;
            QString line = file.readLine();
            QStringList list=line.split(" ");
            infoItem* item= new infoItem(list[0].toStdString(),list[1].toStdString(),list[2].toStdString(),list[3].toStdString());
            layout->addWidget(item);
            //connect(item,infoItemSignal,this,sayf);
        }


        int layout_width = 200;
        int layout_height = topLevelWidget()->height();

        cout<<"top_level_height"<< layout_height<<endl;
        cout<<"Width1:"<<this->width()<<endl;
        cout<<"Height1:"<<this->height()<<endl;

        resize(layout_width, layout_height*2);

        setLayout(layout);
    }
    std::string getName() override{
        return "RightScrollInnerWidget";
    };
    void sayf(string word){
        cout << word << endl;
    }

public slots:
    void writeToFile(string name,string timelong,string author,string sourceURL){
        QFile file("set.txt");
        if (!file.open(QIODevice::WriteOnly | QIODevice::Text)){
            cout << "file does not exist! " << endl;
            return;
        }
        QTextStream stream(&file);
        QString fname = QString::fromStdString(name);
        QString ftime = QString::fromStdString(timelong);
        QString fauthor = QString::fromStdString(author);
        QString fsourceURL = QString::fromStdString(sourceURL);
        QString out = fname+" "+ftime+" "+fauthor+" "+fsourceURL;
        stream<<out<<"\n";
        file.close();
        infoItem* item= new infoItem(name,timelong,author,sourceURL);
        layout->addWidget(item);
        this->update();
    }

};

#endif // RIGHTSCROLLINNERWIDGET_H

#ifndef VOLUME_WIDGET_H
#define VOLUME_WIDGET_H
#include "base_widget.h"
#include <string>
using namespace std;
class VolumeWidget: public BaseWidget{
public:
    VolumeWidget();
    string getName() override{
        return "VolumeWidget";
    }
};
#endif // VOLUME_WIDGET_H

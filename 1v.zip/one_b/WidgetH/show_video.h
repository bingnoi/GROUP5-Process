#ifndef SHOW_VIDEO_H
#define SHOW_VIDEO_H
#include <QWidget>
#include<QtCore/QObject>
#include <QPushButton>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <WidgetH/set_bar.h>
#include <WidgetH/nav_bar.h>
#include <QMouseEvent>
#include <myvideowidget.h>
#include <LayoutH/show_video_layout.h>
class QMediaPlayer;
class QVideoWidget;
class show_video:public QWidget{
    Q_OBJECT
public:
    ShowVideoLayout* mainLayout;
    show_video();
    void toggleSidebar(QString);
    void pause();
    void play();
    void control();
    void SliderRealse();
private slots:
    void getAlltime(qint64);
    void getCurtime(qint64);
    void onTimeOut(qint64);
    void SliderClicked(int);
    void SliderMove(int);
    void volume(int);
    void next();
    void pre();
    void info(string,string,string,string);
protected:
    void mouseMoveEvent(QMouseEvent *event);
private:
    QPoint position;
signals:
    void pausevideo();
    void playvideo();
    void controlvideo();
    void durationchange(qint64);
    void positionchange(qint64);
    void costomSliderClicked(int);
    void movevideo(int);
    void realsevideo();
    void Sliderchange(qint64);
    void changevolume(int);
    void fastnext();
    void fastpre();
    void videoinfo(string,string,string,string);
};

#endif // SHOW_VIDEO_H


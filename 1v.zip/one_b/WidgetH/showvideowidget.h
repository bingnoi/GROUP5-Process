#ifndef SHOWVIDEOWIDGET_H
#define SHOWVIDEOWIDGET_H
#include <base_widget.h>
#include<QtCore/QObject>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlayer>
#include <QVideoWidget>
#include <string>
#include <qtimer.h>
class QMediaPlayer;
class QVideoWidget;
using namespace std;
class ShowVideoWidget : public BaseWidget{
    Q_OBJECT
public:
    ShowVideoWidget();
    string getName() override{
        return "ShowVideoWidget";
    }
    void pause();
    void play();
    void control();
    void SliderRealse();
    void next();
    void pre();
private slots:
    void getAlltime(qint64);
    void getCurtime(qint64);
    void onTimeOut();
    void SliderClicked(int);
    void SliderMove(int);
    void volume(int);
signals:
    void durationchange(qint64);
    void positionchange(qint64);
    void Sliderchange(qint64);
    void videoinfo(string,string,string,string);
private:
    QMediaPlayer * player;
    QVideoWidget * videoWidget;
    QTimer* timer;
    int maxValue = 1000;
    qint64 total;
    QString name;
    QString url;
};

#endif // SHOWVIDEOWIDGET_H

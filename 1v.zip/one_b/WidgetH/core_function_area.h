#ifndef CORE_FUNCTION_AREA_H
#define CORE_FUNCTION_AREA_H
#include<base_widget.h>
#include <myslider.h>
#include <iostream>
using namespace std;
class CoreFunctionArea : public BaseWidget
{
    Q_OBJECT
public:
    CoreFunctionArea();
    string getName() override{
        return "CoreFunctionArea";
    }
    void pause();
    void play();
    void control();
    void volume();
signals:
    void pausevideo();
    void playvideo();
    void controlvideo();
    void changevolume(int);
private:
    MySlider* volume_e;
};

#endif // CORE_FUNCTION_AREA_H

#ifndef TIME_PROGRESS_H
#define TIME_PROGRESS_H
#include "base_widget.h"
#include <string>
#include <QLabel>
using namespace std;
class TimeProgress : public BaseWidget{
    Q_OBJECT
public:
    TimeProgress();
    string getName() override{
        return "TimeProgress";
    }
    QLabel* Cur;
    QLabel* Sum;
private slots:
    void getAlltime(qint64);
    void getCurtime(qint64);
};
#endif // TIME_PROGRESS_H


<<<<<<< HEAD
#ifndef CLICK_BAR_H
#define CLICK_BAR_H
#include<QWidget>
#include <QtGui>
#include <QList>
#include <QLayout>
class click_bar:public QWidget{
public:
    click_bar(QWidget *parent = 0);
    ~click_bar();
private:
   QList<QLable*> list;
};

#endif // CLICK_BAR_H
=======
#ifndef CLICK_BAR_H
#define CLICK_BAR_H
#include<QWidget>
#include <QtGui>
#include <QList>
#include <QLayout>
class click_bar:public QWidget{
public:
    click_bar(QWidget *parent = 0);
    ~click_bar();
private:
   QList<QLable*> list;
};

#endif // CLICK_BAR_H
>>>>>>> lxh

//音量控件，使用VolumeLayout对内部子控件进行布局


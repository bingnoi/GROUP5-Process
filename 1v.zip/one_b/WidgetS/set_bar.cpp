#include <WidgetH/set_bar.h>
#include <QWidget>
#include <QPalette>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <WidgetH/progress_bar.h>
#include <WidgetH/set_bar_function_area.h>
#include <LayoutH/set_bar_layout.h>
using namespace std;
SetBar::SetBar(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(100,100,100));
    setAutoFillBackground(true);
    setPalette(p);
    SetBarLayout* hLayout = new SetBarLayout();
    ProgressBar* progreeeBar = new ProgressBar();
    SetBarFunctionArea* functionArea = new SetBarFunctionArea();
    connect(functionArea,&SetBarFunctionArea::pausevideo,this,&SetBar::pause);
    connect(functionArea,&SetBarFunctionArea::playvideo,this,&SetBar::play);
    connect(functionArea,&SetBarFunctionArea::controlvideo,this,&SetBar::control);
    connect(functionArea,SIGNAL(changevolume(int)),this,SLOT(volume(int)));
    connect(progreeeBar,SIGNAL(costomSliderClicked(int)),this,SLOT(SliderClicked(int)));
    connect(progreeeBar,SIGNAL(movevideo(int)),this,SLOT(SliderMove(int)));
    connect(progreeeBar,&ProgressBar::relasevideo,this,&SetBar::SliderRealse);
    connect(progreeeBar,&ProgressBar::fastnext,this,&SetBar::next);
    connect(progreeeBar,&ProgressBar::fastpre,this,&SetBar::pre);


    connect(this,SIGNAL(durationchange(qint64)),functionArea,SLOT(getAlltime(qint64)));
    connect(this,SIGNAL(durationchange(qint64)),progreeeBar,SLOT(getAlltime(qint64)));
    connect(this,SIGNAL(positionchange(qint64)),functionArea,SLOT(getCurtime(qint64)));
    connect(this,SIGNAL(Sliderchange(qint64)),progreeeBar,SLOT(getCurtime(qint64)));
    hLayout->addWidget(progreeeBar);
    hLayout->addWidget(functionArea);
    setLayout(hLayout);
}

void SetBar::pause(){
    emit pausevideo();
}

void SetBar::play(){
    emit playvideo();
}

void SetBar::control(){
    emit controlvideo();
}

void SetBar::getAlltime(qint64 duration){
    emit durationchange(duration);
}

void SetBar::getCurtime(qint64 position){
    emit positionchange(position);
}

void SetBar::onTimeOut(qint64 position){
    emit Sliderchange(position);
}

void SetBar::SliderClicked(int value){
    emit costomSliderClicked(value);
}

void SetBar::SliderMove(int value){
    emit movevideo(value);
}

void SetBar::SliderRealse(){
    emit realsevideo();
}

void SetBar::volume(int value){
    emit changevolume(value);
}

void SetBar::next(){
    emit fastnext();
}

void SetBar::pre(){
    emit fastpre();
}

#include "WidgetH/sidebar.h"
#include <QWidget>
#include <QPalette>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <QMouseEvent>
SideBar::SideBar()
{
    QPalette p;
    p.setColor(QPalette::Window,QColor(00,99,53));
    setAutoFillBackground(true);
    setPalette(p);
}
void SideBar::mousePressEvent(QMouseEvent *event){
    emit mouseClick("Show");
}


#include <WidgetH/nav_bar.h>
#include <QWidget>
#include <QPalette>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
NavBar::NavBar(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(99,99,53));
    setAutoFillBackground(true);
    setPalette(p);

    QLabel* jump = new QLabel("Jump");
    jump->setStyleSheet("color : white");
    QHBoxLayout* hLayout = new QHBoxLayout();
    hLayout->addWidget(jump);
    setLayout(hLayout);

}

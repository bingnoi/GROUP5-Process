#include "WidgetH/show_video.h"
#include "LayoutH/show_video_layout.h"
#include <windows.h>
#include <QWidget>
#include <iostream>
#include <QApplication>
#include <WidgetH/showvideowidget.h>
#include <WidgetH/sidebar.h>
#include <WidgetH/extended_space.h>
using namespace std;
show_video::show_video(){
    SetBar* setBar = new SetBar();
    NavBar* navBar = new NavBar();
    SideBar* sidebar = new SideBar();
    ExtendSpace* extend = new ExtendSpace();
    void (SideBar:: *SideBarClickSignal)(QString )=&SideBar::mouseClick;
    void (ExtendSpace:: *ExtendClickSignal)(QString )=&ExtendSpace::mouseClick;
    void (show_video:: *toggleSidebarslot)(QString )=&show_video::toggleSidebar;
    connect(sidebar,SideBarClickSignal,this,toggleSidebarslot);
    connect(extend,ExtendClickSignal,this,toggleSidebarslot);
    ShowVideoWidget* sv = new ShowVideoWidget();


    connect(setBar,&SetBar::pausevideo,this,&show_video::pause);
    connect(setBar,&SetBar::playvideo,this,&show_video::play);
//    connect(setBar,&SetBar::controlvideo,this,&show_video::control);
//    connect(setBar,SIGNAL(costomSliderClicked(int)),this,SLOT(SliderClicked(int)));
//    connect(sv,SIGNAL(durationchange(qint64)),this,SLOT(getAlltime(qint64)));
//    connect(sv,SIGNAL(positionchange(qint64)),this,SLOT(getCurtime(qint64)));
//    connect(sv,SIGNAL(Sliderchange(qint64)),this,SLOT(onTimeOut(qint64)));
//    connect(setBar,SIGNAL(movevideo(int)),this,SLOT(SliderMove(int)));
//    connect(setBar,&SetBar::realsevideo,this,&show_video::SliderRealse);
//    connect(setBar,SIGNAL(changevolume(int)),this,SLOT(volume(int)));
//    connect(setBar,&SetBar::fastnext,this,&show_video::next);
//    connect(setBar,&SetBar::fastpre,this,&show_video::pre);
//    connect(sv,SIGNAL(videoinfo(string,string,string,string)),this,SLOT(info(string,string,string,string)));

    connect(this,&show_video::pausevideo,sv,&ShowVideoWidget::pause);
    connect(this,&show_video::playvideo,sv,&ShowVideoWidget::play);
//    connect(this,&show_video::controlvideo,sv,&ShowVideoWidget::control);
//    connect(this,SIGNAL(durationchange(qint64)),setBar,SLOT(getAlltime(qint64)));
//    connect(this,SIGNAL(positionchange(qint64)),setBar,SLOT(getCurtime(qint64)));
//    connect(this,SIGNAL(Sliderchange(qint64)),setBar,SLOT(onTimeOut(qint64)));
//    connect(this,SIGNAL(costomSliderClicked(int)),sv,SLOT(SliderClicked(int)));
//    connect(this,SIGNAL(movevideo(int)),sv,SLOT(SliderMove(int)));
//    connect(this,&show_video::realsevideo,sv,&ShowVideoWidget::SliderRealse);
//    connect(this,SIGNAL(changevolume(int)),sv,SLOT(volume(int)));
//    connect(this,&show_video::fastnext,sv,&ShowVideoWidget::next);
//    connect(this,&show_video::fastpre,sv,&ShowVideoWidget::pre);
//    connect(this,SIGNAL(videoinfo(string,string,string,string)),extend,SLOT(info(string,string,string,string)));

    this->setMouseTracking(true);
    setMinimumSize(1280,720);
    this->mainLayout = new ShowVideoLayout();
    mainLayout->addWidget(navBar);
    mainLayout->addWidget(setBar);
    mainLayout->addWidget(sv);
    mainLayout->addWidget(sidebar);
    mainLayout->addWidget(extend);
    setLayout(mainLayout);

}

void show_video::mouseMoveEvent(QMouseEvent *event)
{


    QPoint p_re = event->pos();
    position = p_re;
    ShowVideoLayout* layout = static_cast<ShowVideoLayout*>(this->layout());

    int cursorY = position.y();
    int showState = layout->getShowState();


    if((cursorY > 600 && showState != 1)){

        layout->changeState(1);
        QSize size = this->size();
        QRect rect(0,0,size.width(),size.height());
        this->layout()->setGeometry(rect);
        this->update();
    }
    else if(cursorY >= 80 && cursorY <= 600 && showState != 2){

        layout->changeState(2);
        QSize size = this->size();
        QRect rect(0,0,size.width(),size.height());
        this->layout()->setGeometry(rect);
        this->update();
    }else if(cursorY < 80 && showState != 0){
        layout->changeState(0);
        QSize size = this->size();
        QRect rect(0,0,size.width(),size.height());
        this->layout()->setGeometry(rect);
        this->update();
    }

}

void show_video::toggleSidebar(QString command){
//    cout<<"The size is"<<mainLayout->count()<<endl;
    if(command == "Show"){
//        cout << "Show" << endl;
        mainLayout->setState(1);
        cout<<(mainLayout->widget() == NULL)<<endl;
        QRect currentR = this->geometry();
        mainLayout->setGeometry(currentR);
        this->update();
    }
    else if(command =="Close"){
//        cout << "Close" << endl;
        mainLayout->setState(0);
        cout<<(mainLayout->widget() == NULL)<<endl;
        QRect currentR = this->geometry();
        mainLayout->setGeometry(currentR);
        this->update();
    }

    cout<<"i was clicked"<<endl;
}

void show_video::pause(){
    emit pausevideo();
}

void show_video::play(){
    emit playvideo();
}

void show_video::control(){
    emit controlvideo();
}

void show_video::getAlltime(qint64 duration){
    emit durationchange(duration);
}

void show_video::onTimeOut(qint64 position){
    emit Sliderchange(position);
}

void show_video::getCurtime(qint64 position){
    emit positionchange(position);
}

void show_video::SliderClicked(int value){
    emit costomSliderClicked(value);
}

void show_video::SliderMove(int value){
    emit movevideo(value);
}

void show_video::SliderRealse(){
    emit realsevideo();
}

void show_video::volume(int value){
    emit changevolume(value);
}

void show_video::next(){
    emit fastnext();
}

void show_video::pre(){
    emit fastpre();
}

void show_video::info(string name, string timelong, string author, string url){
    emit videoinfo(name,timelong,author,url);
}

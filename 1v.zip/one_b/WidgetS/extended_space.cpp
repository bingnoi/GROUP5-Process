#include <WidgetH/extended_space.h>
#include <QWidget>
#include <QPalette>
#include <QLabel>
#include <QLayout>
#include <QPushButton>
#include <QMouseEvent>
#include <iostream>
#include <QScrollArea>
#include "LayoutH/extended_space_layout.h"
#include "infoitem.h"
#include "LayoutH/inner_layout.h"
#include "LayoutH/simple_full_layout.h"
#include "WidgetH/RightScrollInnerWidget.h"
ExtendSpace::ExtendSpace(){
    SimpleFullLayout* mlayout = new SimpleFullLayout();

    QScrollArea* area = new QScrollArea();
    mlayout->addWidget(area);

    RightScrollInnerWidget* innerWidget= new RightScrollInnerWidget();
    area->setWidget(innerWidget);

    infoItem* click= new infoItem("Close");
    void (infoItem:: *infoItemSignal)(string )=&infoItem::mouseClick;
    connect(click,infoItemSignal,this,&ExtendSpace::sayClick);
    connect(this,SIGNAL(videoinfo(string,string,string,string)),innerWidget,SLOT(writeToFile(string,string,string,string)));

    mlayout->addWidget(click);
    setLayout(mlayout);
}
void ExtendSpace::sayClick(){
    emit mouseClick("Close");
}

void ExtendSpace::say(string url){
    cout << "The url is " << url << endl;
}

void ExtendSpace::info(string name, string timelong, string author, string url){
    emit videoinfo(name,timelong,author,url);
}




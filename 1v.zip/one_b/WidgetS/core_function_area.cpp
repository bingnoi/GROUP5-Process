#include <WidgetH/core_function_area.h>
#include <QWidget>
#include <QPushButton>
#include <QLabel>
#include <QLayout>
#include <myslider.h>
CoreFunctionArea::CoreFunctionArea(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(237,241,53));
    setAutoFillBackground(true);
    setPalette(p);
    QPushButton* stop = new QPushButton("S");
    QPushButton* pre = new QPushButton("<");
    QPushButton* pause = new QPushButton("P");
    QPushButton* next = new QPushButton(">");
    QPushButton* control = new QPushButton("V");
    volume_e = new MySlider();
    connect(stop,&QPushButton::clicked,this,&CoreFunctionArea::pause);
    connect(pause,&QPushButton::clicked,this,&CoreFunctionArea::play);
    connect(control,&QPushButton::clicked,this,&CoreFunctionArea::control);
    connect(volume_e,&MySlider::costomSliderClicked,this,&CoreFunctionArea::volume);
    connect(volume_e,&MySlider::sliderMoved,this,&CoreFunctionArea::volume);
    volume_e->setOrientation(Qt::Horizontal);
    volume_e->setMinimum(0);
    volume_e->setMaximum(60);
    volume_e->setSingleStep(1);
    volume_e->setFixedWidth(180);
    stop->setFixedWidth(50);
    pre->setFixedWidth(50);
    pause->setFixedWidth(50);
    next->setFixedWidth(50);
    control->setFixedWidth(50);
    QHBoxLayout* layout = new QHBoxLayout();
    layout->addWidget(stop);
    layout->addWidget(pre);
    layout->addWidget(pause);
    layout->addWidget(next);
    layout->addWidget(control);
    layout->addWidget(volume_e);
    setLayout(layout);
}

void CoreFunctionArea::pause(){
    emit pausevideo();
}

void CoreFunctionArea::play(){
    emit playvideo();
}

void CoreFunctionArea::control(){
    emit controlvideo();
}

void CoreFunctionArea::volume(){
    int value = volume_e->value();
    emit changevolume(value);
}

//进度条控件，使用ProgressBarLayout对内部子控件进行布局
#include <QPushButton>
#include <WidgetH/progress_bar.h>
#include <LayoutH/progress_bar_layout.h>
#include <base_slider.h>
#include <QHBoxLayout>
#include <iostream>
using namespace std;
ProgressBar::ProgressBar(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(99,99,53));
    setAutoFillBackground(true);
    setPalette(p);

    QPushButton* pre = new QPushButton("<<");
    pre->setStyleSheet("QPushButton{background-image: url(:./pre_button.jpeg);}" );
    QPushButton* next = new QPushButton(">>");
    pre->setFixedSize(40,25);
    next->setFixedSize(40,25);
    show = new MySlider();
    show->setOrientation(Qt::Horizontal);
    show->setFixedSize(1150,10);

    connect(show,&MySlider::costomSliderClicked,this,&ProgressBar::SliderClicked);
    connect(show,&MySlider::sliderMoved,this,&ProgressBar::SliderMove);
    connect(show,&MySlider::sliderReleased,this,&ProgressBar::SliderRealse);
    connect(next,&QPushButton::clicked,this,&ProgressBar::next);
    connect(pre,&QPushButton::clicked,this,&ProgressBar::pre);

    QHBoxLayout* hLayout = new QHBoxLayout();
    hLayout->addWidget(pre);
    hLayout->addWidget(show);
    hLayout->addWidget(next);
    hLayout->setMargin(3);
    setLayout(hLayout);
}

void ProgressBar::getAlltime(qint64 duration){
    show->setRange(0,1000);
    show->setEnabled(duration>0);
//    show->setPageStep(duration/20);
}

void ProgressBar::getCurtime(qint64 position){
    show->setValue(position);
}

void ProgressBar::SliderClicked(){
    int value = show->value();
    emit costomSliderClicked(value);
}

void ProgressBar::SliderMove(){
    int value = show->value();
    emit movevideo(value);
}

void ProgressBar::SliderRealse(){
    emit relasevideo();
}

void ProgressBar::next(){
    emit fastnext();
}

void ProgressBar::pre(){
    emit fastpre();
}

//时间进度显示控件 xx:xx / yy:yy

//单一控件，主要需要获取视频播放信息并准确显示
#include <WidgetH/time_progress.h>
#include <QWidget>
#include <QPalette>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <WidgetH/time_progress.h>
#include <iostream>
using namespace std;
TimeProgress::TimeProgress(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(237,200,250));
    setAutoFillBackground(true);
    setPalette(p);
    Cur = new QLabel();
    Sum = new QLabel();
    QHBoxLayout* aLayout = new QHBoxLayout();
    Cur->setFixedSize(100,20);
    Sum->setFixedSize(100,20);
    aLayout->addWidget(Cur);
    aLayout->addWidget(Sum);
    setLayout(aLayout);
}

void TimeProgress::getAlltime(qint64 duration){
    cout << duration << endl;
    int h=0,m=0,s=0;
    duration/=1000;
    h = duration/3600;
    m = (duration-h*3600)/60;
    s = duration-h*3600-m*60;
    Sum->setText(QString("%1:%2:%3").arg(h).arg(m).arg(s));
    Sum->setStyleSheet("color:white");
}


void TimeProgress::getCurtime(qint64 position){
    int h=0,m=0,s=0;
    position/=1000;
    h = position/3600;
    m = (position-h*3600)/60;
    s = position-h*3600-m*60;
    Cur->setText(QString("%1:%2:%3").arg(h).arg(m).arg(s));
}

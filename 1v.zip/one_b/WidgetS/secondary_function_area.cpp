#include <QWidget>
#include <WidgetH/secondary_function_area.h>
#include <QLabel>
#include <QLayout>
#include <QPushButton>
SecondaryFunctionArea::SecondaryFunctionArea(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(237,111,153));
    setAutoFillBackground(true);
    setPalette(p);

    QPushButton* fScreen = new QPushButton("Screen");
    QHBoxLayout* layout = new QHBoxLayout();
    layout->addWidget(fScreen);
    setLayout(layout);
}

#include <WidgetH/set_bar_function_area.h>
#include <QWidget>
#include <QPalette>
#include <WidgetH/time_progress.h>
#include <WidgetH/core_function_area.h>
#include <WidgetH/secondary_function_area.h>
#include <LayoutH/set_bar_function_area_layout.h>
#include <QHBoxLayout>
#include <QLabel>
#include <QLayout>
#include <iostream>
using namespace std;
SetBarFunctionArea::SetBarFunctionArea(){
    QPalette p;
    p.setColor(QPalette::Window,QColor(250,241,153));
    setAutoFillBackground(true);
    setPalette(p);
    TimeProgress* tProgress = new TimeProgress();
    CoreFunctionArea* cFunction = new CoreFunctionArea();
    SecondaryFunctionArea* sFunction = new SecondaryFunctionArea();
    SetBarFunctionAreaLayout* hLayout = new SetBarFunctionAreaLayout();
    connect(cFunction,&CoreFunctionArea::pausevideo,this,&SetBarFunctionArea::pause);
    connect(cFunction,&CoreFunctionArea::playvideo,this,&SetBarFunctionArea::play);
    connect(cFunction,&CoreFunctionArea::controlvideo,this,&SetBarFunctionArea::control);
    connect(cFunction,SIGNAL(changevolume(int)),this,SLOT(volume(int)));
    connect(this,SIGNAL(durationchange(qint64)),tProgress,SLOT(getAlltime(qint64)));
    connect(this,SIGNAL(positionchange(qint64)),tProgress,SLOT(getCurtime(qint64)));
    hLayout->addWidget(tProgress);
    hLayout->addWidget(cFunction);
    hLayout->addWidget(sFunction);
    hLayout->setMargin(3);
    setLayout(hLayout);
}

void SetBarFunctionArea::pause(){
    emit pausevideo();
}

void SetBarFunctionArea::play(){
    emit playvideo();
}

void SetBarFunctionArea::control(){
    emit controlvideo();
}

void SetBarFunctionArea::getAlltime(qint64 duration){
    emit durationchange(duration);
}

void SetBarFunctionArea::getCurtime(qint64 position){
    emit positionchange(position);
}

void SetBarFunctionArea::volume(int value){
    emit changevolume(value);
}

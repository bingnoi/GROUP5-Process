#include <WidgetH/showvideowidget.h>
#include <QLayout>
#include <QPalette>
#include <iostream>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QDesktopServices>
#include <QImageReader>
#include <QMessageBox>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
using namespace std;
ShowVideoWidget::ShowVideoWidget(){
    videoWidget = new QVideoWidget(this);
    player = new QMediaPlayer(this);
    player->setVideoOutput(videoWidget);
    videoWidget->setFixedSize(1200,600);
    QString path="D:\\videos\\b.wmv";
    QStringList list = path.split("\\");
    name = list[2];
//    name = "py";
    url = path;
    player->setMedia(QUrl::fromLocalFile(path));    //设置视频本地路径
    timer = new QTimer();
    timer->setInterval(100);
    timer->start();
    connect(player,SIGNAL(durationChanged(qint64)),this,SLOT(getAlltime(qint64)));
    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(getCurtime(qint64)));
    connect(timer,SIGNAL(timeout()),this,SLOT(onTimeOut()));
    player->play();
}

//设为暂停
void ShowVideoWidget::pause(){
    player->pause();
}

//设为播放
void ShowVideoWidget::play(){
    player->play();
}

//设置静音
void ShowVideoWidget::control(){
    bool mute = player->isMuted();
    player->setMuted(!mute);
}

//获得总时长
void ShowVideoWidget::getAlltime(qint64 duration){
    duration = player->duration();
    total = duration;
    string py = "py";
//    cout << name.toStdString()<< endl;
    emit videoinfo(name.toStdString(),QString("%1").arg(total).toStdString(),py,url.toStdString());
    emit durationchange(duration);
}

//更新滚动条的信息
void ShowVideoWidget::onTimeOut(){
    emit Sliderchange(player->position()*1000/player->duration());
}

//更新时间戳
void ShowVideoWidget::getCurtime(qint64 position){
    position=player->position();
    emit positionchange(position);
}

//获得点击滚动条的位置
void ShowVideoWidget::SliderClicked(int value){
    player->setPosition(value*total/1000);
}

//滚动条移动
void ShowVideoWidget::SliderMove(int value){
    timer->stop();
    player->setPosition(value*total/1000);
}

//时间轴重新进行
void ShowVideoWidget::SliderRealse(){
    timer->start();
}

//更改音量
void ShowVideoWidget::volume(int value){
    player->setVolume(value);
}

void ShowVideoWidget::next(){
    player->setPosition(player->position()+(total/20));
}

void ShowVideoWidget::pre(){
    player->setPosition(player->position()-(total/20));
}

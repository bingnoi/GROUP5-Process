#ifndef BASE_SLIDER_H
#define BASE_SLIDER_H
#include <QSlider>
#include <string>
using namespace std;
class BaseSlider : public QSlider{
public:
    void addName(string name){
        this->Kname = name;
    }
    string text(){
        return this->Kname;
    }

private:
    string Kname;
};

#endif // BASE_SLIDER_H

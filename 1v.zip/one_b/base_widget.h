#ifndef BASE_WIDGET_H
#define BASE_WIDGET_H
#include <QWidget>
#include <string>
using namespace std;
class BaseWidget : public QWidget{
public:
    virtual string getName() = 0;
};

#endif // BASE_WIDGET_H

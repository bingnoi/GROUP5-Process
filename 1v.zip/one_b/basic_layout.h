#ifndef BASIC_LABEL_H
#define BASIC_LABEL_H
#include <QLayout>
class BasicLayout : public QLayout
{
public:
    virtual void setGeometry(const QRect &rect) = 0;

    void addItem(QLayoutItem *item){
        list.append(item);
    };

    QSize sizeHint() const{
        return QSize(0,0);
    };
    QSize minimumSize() const{
        return QSize(0,0);
    };
    int count() const{
        return list.size();
    };
    QLayoutItem *itemAt(int index) const{
        return list.value(index);
    };
    QLayoutItem *takeAt(int index){
        return index >= 0 && index < list.size() ? list.takeAt(index) : 0;
    };
    void addWidget(QWidget* w){
        list.append(new QWidgetItem(w));
    };
protected:
    QList<QLayoutItem*> list;
};

#endif // BASIC_LAYOUT_H
